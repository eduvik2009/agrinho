let personagem;
let terreno;
let cidade;
let sementes = 20; // Começa com algumas sementes
let frutosColetados = 0;
let energia = 100; // Energia inicial
let arvoresPlantadas = 0;

// Novas variáveis para a temperatura e controle do céu
let temperatura = 30; // Temperatura inicial (ex: 30 graus - alto)
const TEMPERATURA_MAX = 40; // Temperatura máxima (muito quente)
const TEMPERATURA_MIN = 10; // Temperatura mínima (mais fresco)

// Posições e tamanhos
let personagemX, personagemY;
let personagemTamanho = 30;
let velocidadePersonagem = 3;

// Arrays para armazenar as árvores e frutos
let arvores = [];
let frutosNoChao = [];

// Variável para a plantação
let plantacao;

// Classe para o Personagem (com modificação em plantarArvore)
class Personagem {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.tamanho = personagemTamanho;
  }

  mostrar() {
    fill(0, 150, 0); // Cor do personagem (ex: verde)
    rect(this.x, this.y, this.tamanho, this.tamanho);
  }

  mover() {
    // Lógica de movimentação baseada nas setas do teclado
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= velocidadePersonagem;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += velocidadePersonagem;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= velocidadePersonagem;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += velocidadePersonagem;
    }

    // Limitar o personagem dentro da tela
    this.x = constrain(this.x, 0, width - this.tamanho);
    this.y = constrain(this.y, 0, height - this.tamanho);
  }

  plantarArvore() {
    // Agora só podemos plantar árvores dentro da área da plantação
    if (sementes > 0 && energia >= 10) {
      if (this.x > plantacao.x && this.x < plantacao.x + plantacao.largura &&
          this.y > plantacao.y && this.y < plantacao.y + plantacao.altura) {
        arvores.push(new Arvore(this.x, this.y));
        sementes--;
        energia -= 10;
        arvoresPlantadas++;
        // Diminui a temperatura a cada árvore plantada
        temperatura -= 0.5; // Diminui em 0.5 graus por árvore
        temperatura = constrain(temperatura, TEMPERATURA_MIN, TEMPERATURA_MAX); // Garante que fica dentro dos limites
        console.log("Árvore plantada! Árvores totais: " + arvoresPlantadas + ", Temperatura: " + temperatura.toFixed(1) + "°C");
      } else {
        console.log("Você só pode plantar árvores dentro da área da plantação!");
      }
    } else if (sementes === 0) {
      console.log("Sem sementes!");
    } else {
      console.log("Sem energia suficiente para plantar!");
    }
  }

  colherFruto() {
    // Lógica para colher frutos próximos
    for (let i = frutosNoChao.length - 1; i >= 0; i--) {
      let fruto = frutosNoChao[i];
      let d = dist(this.x, this.y, fruto.x, fruto.y);
      if (d < this.tamanho + fruto.tamanho / 2 && energia >= 5) { // Custo de energia para colher
        frutosColetados++;
        energia -= 5;
        frutosNoChao.splice(i, 1); // Remove o fruto do chão
        console.log("Fruto coletado! Total: " + frutosColetados);
        break; // Colhe apenas um fruto por vez
      } else if (energia < 5) {
        console.log("Sem energia suficiente para colher!");
      }
    }
  }

  entregarFrutos() {
    // Se o personagem estiver perto da cidade
    let distanciaParaCidade = dist(this.x, this.y, cidade.x + cidade.largura / 2, cidade.y + cidade.altura / 2);
    if (distanciaParaCidade < 100 && frutosColetados > 0) {
      console.log("Frutos entregues na cidade! Total entregue: " + frutosColetados);
      frutosColetados = 0; // Zera os frutos depois de entregar
      // Você pode adicionar um score ou um objetivo aqui
    } else if (frutosColetados === 0) {
      console.log("Nenhum fruto para entregar!");
    } else {
      console.log("Você precisa estar mais perto da cidade para entregar os frutos.");
    }
  }

  recuperarEnergia() {
    // Simplesmente para o personagem recuperar energia ao "descansar" (ficar parado ou com uma ação específica)
    if (energia < 100) {
      energia += 0.1; // Recupera lentamente
      energia = constrain(energia, 0, 100);
    }
  }
}

// Classe para a Árvore (mantida a mesma)
class Arvore {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.tamanho = 40;
    this.tempoParaFruto = frameRate() * 10 * random(5, 15); // Tempo para gerar um fruto (10 a 15 segundos)
    this.framesPassados = 0;
  }

  mostrar() {
    fill(139, 69, 19); // Tronco (marrom)
    rect(this.x + this.tamanho / 4, this.y + this.tamanho / 2, this.tamanho / 2, this.tamanho / 2);
    fill(34, 139, 34); // Folhas (verde)
    ellipse(this.x + this.tamanho / 2, this.y + this.tamanho / 4, this.tamanho * 0.8, this.tamanho * 0.8);
  }

  gerarFruto() {
    this.framesPassados++;
    if (this.framesPassados >= this.tempoParaFruto) {
      // Gera o fruto em uma posição próxima à árvore
      frutosNoChao.push(new Fruto(this.x + random(-20, 20), this.y + random(-20, 20)));
      this.framesPassados = 0; // Reseta o contador
      this.tempoParaFruto = frameRate() * 10 * random(5, 15); // Novo tempo para o próximo fruto
      console.log("Um fruto caiu!");
    }
  }
}

// Classe para o Fruto (mantida a mesma)
class Fruto {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.tamanho = 15;
  }

  mostrar() {
    fill(255, 0, 0); // Cor do fruto (ex: vermelho)
    ellipse(this.x, this.y, this.tamanho, this.tamanho);
  }
}

// Classe para a Cidade (mantida a mesma)
class Cidade {
  constructor(x, y, largura, altura) {
    this.x = x;
    this.y = y;
    this.largura = largura;
    this.altura = altura;
  }

  mostrar() {
    fill(150); // Cor da cidade (cinza)
    rect(this.x, this.y, this.largura, this.altura);
    fill(255);
    textSize(12);
    textAlign(CENTER, CENTER);
    text("CIDADE", this.x + this.largura / 2, this.y + this.altura / 2);
  }
}

// Classe para a Plantação (mantida a mesma)
class Plantacao {
  constructor(x, y, largura, altura) {
    this.x = x;
    this.y = y;
    this.largura = largura;
    this.altura = altura;
  }

  mostrar() {
    fill(100, 150, 50, 150); // Cor mais clara para a área da plantação (verde claro com transparência)
    rect(this.x, this.y, this.largura, this.altura);
    fill(50);
    textSize(12);
    textAlign(CENTER, CENTER);
    text("PLANTAÇÃO", this.x + this.largura / 2, this.y + this.altura / 2);
  }
}


function setup() {
  createCanvas(800, 600);
  personagem = new Personagem(width / 2, height / 2);
  terreno = { x: 0, y: 0, largura: width, altura: height }; // O terreno é toda a tela
  cidade = new Cidade(width - 150, height - 150, 100, 100); // Cidade no canto inferior direito

  // Definindo a área da plantação
  plantacao = new Plantacao(50, height / 2 - 100, 300, 250); // Uma área no lado esquerdo
}

function draw() {
  // Calcula a cor do céu com base na temperatura
  let r = map(temperatura, TEMPERATURA_MIN, TEMPERATURA_MAX, 0, 255); // Mais azul (0) quando frio, mais vermelho (255) quando quente
  let b = map(temperatura, TEMPERATURA_MIN, TEMPERATURA_MAX, 255, 0); // Mais azul (255) quando frio, menos azul (0) quando quente
  let g = map(temperatura, TEMPERATURA_MIN, TEMPERATURA_MAX, 150, 100); // Um pouco de verde para suavizar a transição
  background(r, g, b); // Define a cor do céu

  fill(0, 100, 0); // Grama (verde escuro)
  rect(0, height / 2, width, height / 2); // Metade inferior da tela para a grama

  cidade.mostrar();
  plantacao.mostrar(); // Desenha a área da plantação

  // Desenhar árvores e fazer com que gerem frutos
  for (let arvore of arvores) {
    arvore.mostrar();
    arvore.gerarFruto();
  }

  // Desenhar frutos no chão
  for (let fruto of frutosNoChao) {
    fruto.mostrar();
  }

  personagem.mostrar();
  personagem.mover();
  personagem.recuperarEnergia(); // Recupera energia continuamente

  // Exibir informações na tela
  fill(0);
  textSize(16);
  text(`Sementes: ${sementes}`, 10, 20);
  text(`Frutos Coletados: ${frutosColetados}`, 10, 40);
  text(`Energia: ${floor(energia)}%`, 10, 60);
  text(`Árvores Plantadas: ${arvoresPlantadas}`, 10, 80);
  text(`Temperatura: ${temperatura.toFixed(1)}°C`, 10, 100); // Exibe a temperatura

  // Mensagem de objetivo
  if (arvoresPlantadas < 10) {
    text("Plante mais árvores para diminuir o aquecimento!", width / 2, 20);
  } else {
    text("Ótimo trabalho! Continue plantando e colhendo!", width / 2, 20);
  }
}

function keyPressed() {
  // Tecla 'P' para plantar uma árvore
  if (key === 'p' || key === 'P') {
    personagem.plantarArvore();
  }
  // Tecla 'C' para colher frutos
  if (key === 'c' || key === 'C') {
    personagem.colherFruto();
  }
  // Tecla 'E' para entregar frutos na cidade
  if (key === 'e' || key === 'E') {
    personagem.entregarFrutos();
  }
}
